
@extends ('adminlayouts.master')

@section('title', 'Team View')

@section('content')
<head>
    <script src="{{ asset('js/jquery-3.4.1.min.js')}}"></script>
    <script src="{{ asset('js/app.js')}}"></script>
    <link href="{{ asset('css/css2/team.css') }}" rel="stylesheet">

</head>

<div class="container-fluid">
        <br><br>


<div class="dropcontainer">
            <div class="droptarget">

                <p draggable="true" id="dragtarget9">Student1</p>
                <p draggable="true" id="dragtarget10">Student2</p>
                <p draggable="true" id="dragtarget11">Student3</p>
                <p draggable="true" id="dragtarget12">Student4</p>
                <p draggable="true" id="dragtarget13">Student5</p>
                <p draggable="true" id="dragtarget18">Student10</p>
                <p draggable="true" id="dragtarget19">Student11</p>
                <p draggable="true" id="dragtarget24">Student16</p>
                <p draggable="true" id="dragtarget25">Student17</p>
                <p draggable="true" id="dragtarget26">Student18</p>
                <p draggable="true" id="dragtarget27">Student19</p>

            </div>



            <div class="droptarget">
                <p draggable="true" id="dragtarget">Gary</p>
                <p draggable="true" id="dragtarget2">Huss</p>
                <p draggable="true" id="dragtarget3">Chris</p>
                <div>
                    <p draggable="true" id="dragtarget4">Benan</p>
                </div>
            </div>

            <div class="droptarget">
                <p draggable="true" id="dragtarget20">Student12</p>
                <p draggable="true" id="dragtarget21">Student13</p>
                <p draggable="true" id="dragtarget22">Student14</p>
                <p draggable="true" id="dragtarget23">Student15</p>

            </div>



            <div class="droptarget">
                <p draggable="true" id="dragtarget5">Jack</p>
                <p draggable="true" id="dragtarget6">Derryn</p>
                <p draggable="true" id="dragtarget7">JustinB</p>
                <p draggable="true" id="dragtarget8">Ken</p>
            </div>
            <div class="droptarget">

                <p draggable="true" id="dragtarget14">Student6</p>
                <p draggable="true" id="dragtarget15">Student7</p>
                <p draggable="true" id="dragtarget16">Student8</p>
                <p draggable="true" id="dragtarget17">Student9</p>

            </div>


        </div>

        <button class="btn btn-primary" onclick="location.href='{{ url('teamedit') }}'" style="margin-left: 2%; width:8%;"> Edit </button>






</div>



@endsection
