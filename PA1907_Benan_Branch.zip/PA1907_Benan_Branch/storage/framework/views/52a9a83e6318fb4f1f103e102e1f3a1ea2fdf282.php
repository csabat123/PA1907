

<div class="bg-light border-right" id="sidebar-wrapper">
            <div class="sidebar-heading">Professional Development</div>
            <div class="list-group list-group-flush">
                <a href="index.html" class="list-group-item list-group-item-action bg-light">Dashboard</a>
                <a href="team.html" class="list-group-item list-group-item-action bg-light">Team Manager</a>
                <a href="update.html" class="list-group-item list-group-item-action bg-light">Group Update</a>
                <a href="event.html" class="list-group-item list-group-item-action bg-light">Updates</a>
                <a href="story.html" class="list-group-item list-group-item-action bg-light">Story Board</a>
            </div>
        </div>
<?php /**PATH I:\Gary\laravel\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>